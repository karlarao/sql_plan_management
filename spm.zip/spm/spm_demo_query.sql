select * from skew where skew=3;
select * from table(dbms_xplan.display_cursor);

